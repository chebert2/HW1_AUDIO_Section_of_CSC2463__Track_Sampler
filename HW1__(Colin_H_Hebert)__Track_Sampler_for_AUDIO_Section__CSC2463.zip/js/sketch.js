
// Student :  Colin H Hebert     in CSC 2463  (at LSU Spring 2022)

//  HW 5    
//
//
// link to MP4 video showing the code in action:
//
//  https://lsumail2-my.sharepoint.com/:f:/g/personal/cheb168_lsu_edu/End-yGqQ1kVNp0RjByfjWAkBEmxA-aIR1AUVt4Z5sKp_3g?e=jtjCmk


//  repository zip file uploaded to the following git webpage.
//
//  https://github.com/chebert2/HW1_AUDIO_Section_of_CSC2463__Track_Sampler
//
//


let players;

let slider1;

// slider value variable
let val;

// a String frequency parameter for autopanning effect
let str_val = "2n";

// a crushBits parameter value for that effect
let crushBits_val = 14;

let bool_bit_crusher_and_distortion_is_on = true;

// a distortion parameter value for that effect
let distortion_level = 0.84;

// globally assigned variable for whether [a] track/s loop/s.
let loop_enabled = false;





function preload(){
  players = new Tone.Players({
    't_01': "media/t_01.ogg",
    't_02': "media/t_02.ogg",
    't_03': "media/t_03.ogg",
    't_04': "media/t_04.ogg"
  }).connect(autoPanner);
}




// initialize a finally added distortion effect.
let distortion = new Tone.Distortion(0.84).toDestination();

// initialize a second bit crusher and route a synth through it
let crusher2 = new Tone.BitCrusher(crushBits_val).connect(distortion);

  
// initialize crusher and route a synth through it
let crusher = new Tone.BitCrusher(crushBits_val).connect(crusher2);



// create an autopanner and start it
let autoPanner = new Tone.AutoPanner(str_val).connect(crusher).start();



//function keyPressed(){
//   players.player('t_01').start();
//}


function setup() {

  createCanvas(1300, 800);

  button1 = createButton("cave organ clip");

  button1.position(40, 58);

  button1.mousePressed( () => play1(1) );


  button2 = createButton("lavish meditative music");

  button2.position(40, 116);

  button2.mousePressed( () => play1(2) );
  

  button3 = createButton("temple_electric_render");

  button3.position(40, 174);

  button3.mousePressed( () => play1(3) );
  

  button4 = createButton("full_bodied_timbre");

  button4.position(40, 234);

  button4.mousePressed( () => play1(4) );


  slider1 = createSlider(0, 100, 50, 02);

  slider1.position(40, 323);

  slider1.mouseReleased(()=>{
    
    val = slider1.value();

    if(val >= 86){
      str_val = "1n";
    } else if(val >= 72){
      str_val = "2n";
    } else if(val >= 58){
      str_val = "4n";
    } else if(val >= 44){
      str_val = "8n";
    } else if(val >= 30){
      str_val = "16n";
    } else if(val >= 16){
      str_val = "32n";
    } else if(val >= 2){
      str_val = "64n";
    } 
    
    autoPanner.frequency = str_val;

  });


  
  button5 = createButton("toggle Bit Crusher WITH DISTORTION ON/OFF (at end of effects chain)");

  button5.position(200, 357);

  button5.mousePressed(toggle_bit_crusher);



  button6 = createButton("TURN_TRACK__LOOPING__to__ON__or__OFF_!");

  button6.position(230, 60);

  button6.mousePressed( () => enable_or_disable_looping() );
   
}




function mouseMoved() {

  hypontenuse = Math.sqrt (mouseX*mouseX + mouseY*mouseY) ;

  if(hypontenuse <= 78){
    crushBits_val = 14;
    distortion_level = 0.04;
  } 
  else if(hypontenuse <= 150){
    crushBits_val = 13;
    distortion_level = 0.09;
  } 
  else if(hypontenuse <= 312){
    crushBits_val = 12;
    distortion_level = 0.19;
  }
  else if(hypontenuse <= 430){
    crushBits_val = 10;
    distortion_level = 0.32;
  }
  else if(hypontenuse <= 640){
    crushBits_val = 8;
    distortion_level = 0.46;
  }
  else if(hypontenuse <= 780){
    crushBits_val = 5;
    distortion_level = 0.67;
  } 
  else if(hypontenuse <= 1000){
    crushBits_val = 4;
    distortion_level = 0.73;
  } 
  else if(hypontenuse <= 1300){
    crushBits_val = 3;
    distortion_level = 0.80;
  } 
  else if(hypontenuse <= 1560){
    crushBits_val = 2;
    distortion_level = 0.87;
  } 

  crusher.bits = crushBits_val;

  distortion.distortion = distortion_level;
}




function toggle_bit_crusher(){

  if(bool_bit_crusher_and_distortion_is_on){

    bool_bit_crusher_and_distortion_is_on = false;

    autoPanner.toDestination().start();


  } else {

    bool_bit_crusher_and_distortion_is_on = true;

    autoPanner.connect(crusher).start();

  }

  

}

function draw() {
  background(220);

  stroke(0);
  strokeWeight(0);
  
  // Text label  for   Freq. Shifter Effect
  fill(130, 78,98);
  textSize(27);

  text("Freq. Shifter Effect", 40, 302);

  fill(130, 78,98);
  textSize(27);



      // Text label  for   Bit Crusher and ADDED Distortion   on/off status

  if(bool_bit_crusher_and_distortion_is_on == true){

     fill(15, 78, 35);

     textSize(18);

     text("Bit Crusher and ADDED Distortion is: ON", 200, 398);



     fill(13, 68, 150);

     textSize(18);

     text("Bit Crusher \"input value\" (where there is higher", 220, 428);


     fill(13, 68, 150);

     textSize(18);

     text("'degradation' for lower values) :  ", 220, 447);
     



     fill(13, 68, 150);

     textSize(24);

     text(crushBits_val, 220, 492);


  } else {


     fill(15, 78, 35);

     textSize(18);

     text("Bit Crusher and ADDED distortion is: OFF ", 200, 398); 
    
  }

    // Text label  for   Looping   Status
  if(loop_enabled == true){

     fill(13, 68, 150);

     textSize(24);

     text("Looping ON", 320, 36);

  } else {
    fill(13, 68, 150);

    textSize(24);

    text("Looping off", 320, 36);
  }



   // constructing a reference arrow line drawing to
  // demonstrate the effects amplification/feedback 
  // response layout.


  fill(80, 60, 15);

  textSize(31);

  text("Bit Crush and Distortion INCREASE IN THIS", 672, 260);


  fill(80, 60, 15);

  textSize(31);

  text("DIRECTION", 693, 306);

  
 // drawing the line now.

  stroke(30);
  strokeWeight(9);

  line(332, 211, 1260, 726);

  line(1260, 670, 1260, 726);

  line(1196, 740, 1260, 726);



  

}

function play1(input_int){
  if(input_int == 1){
      players.player('t_01').start();
  }
  else if(input_int == 2){
    players.player('t_02').start();
  }
  else if(input_int == 3){
    players.player('t_03').start();
  }
  else if(input_int == 4){
    players.player('t_04').start();
  } 

}

function enable_or_disable_looping(){

  if(loop_enabled == true){
    loop_enabled = false;
  } else {
    loop_enabled = true;
  }

  players.player('t_01').loop = loop_enabled;
  players.player('t_02').loop = loop_enabled;
  players.player('t_03').loop = loop_enabled;
  players.player('t_04').loop = loop_enabled;

}
